// CarModel class yaratilsin. bu classda 'color, type' maydonlar bo'lsin
// Ford class CarModel dan meros olsin. bu Ford da 'model, year, distance' maydonlaridan tashqari
// getDistancePerYear metodi bor ---> bir yilda bosib o'tgan masofani hisoblasin

// product ---> class (model,price,discount) --> getPriceByDiscount()
// apple   ---> extends ('iphoneXS',1200,10%) ---> 
// new apple ->> let iphoneXS.getPriceByDiscount()
class User {
    constructor(login,pass,role){
        this.login = login
        this.pass  = pass
        this.role  = role
    }
}
class AdminUser extends User {
    constructor(login,pass,role){
        super(login,pass,role)
    }
    getUsers(){
        console.log('123 ta user bor')
    }
    getUserById(){
        console.log('Alisherov Aziz')
    }
    delUserById(){
        console.log('23 id user o`chirildi')
    }
}
let bigboss = new AdminUser('boss','qwetyr','admin')
bigboss.getUsers()

class SimpleUser extends User {
    constructor(login,pass,role){
        super(login,pass,role)
    }
    sendMessage(){
        console.log(this.login+' dan xabar ketdi')
    }
    settings(){
        console.log('oldingi '+this.pass+' parol o`zgardi')
    }
}

let bboy = new SimpleUser('bboy',';jshklfjsad','user')

bboy.sendMessage()

