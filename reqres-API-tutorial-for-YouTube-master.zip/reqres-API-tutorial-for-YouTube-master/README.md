# reqres-API-tutorial-for-YouTube

Link to tutorial - https://youtu.be/mxlNGxTYW2I
