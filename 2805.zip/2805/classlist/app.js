let btn = document.querySelector('button')
btn.addEventListener('click',function(){
    document.querySelector('.menu').classList.toggle('active')
})


// eval(13+65-4*12)


function klik(t){
    console.log(t)
}